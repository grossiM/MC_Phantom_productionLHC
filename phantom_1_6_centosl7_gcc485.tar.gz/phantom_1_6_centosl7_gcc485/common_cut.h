

* CUT COMMONS

      COMMON/icutdata/
     &   i_e_min_lep,i_pt_min_lep,
     &   i_eta_max_onelep,
     &   i_eta_max_lep,i_ptmiss_min,
     &   i_e_min_j,i_pt_min_j,i_eta_max_j,i_eta_jf_jb_jc,
     &   i_pt_min_jcjc,i_rm_min_jj,i_rm_min_ll,i_rm_min_jlep,
     &   i_rm_min_jcjc,i_rm_max_jcjc, i_rm_min_jfjb,
* six
     &   i_rm_min_4l,i_rm_min_2l2cq,
* YR
     &   i_rm_max_4l,i_rm_max_2l2cq,
* YRend
* sixend
* cuttop
     &   i_deltacuttop, 
* cuttopend
*ww
     &   i_cutwlept,i_cutptwelectron,
*wwend
*zw
     &   i_cutzlept,
*zwend
     &   i_eta_min_jfjb,
     &   i_d_ar_jj,i_d_ar_jlep,i_d_ar_leplep,
     &   i_thetamin_jj,i_thetamin_jlep,
     &   i_thetamin_leplep,
     &   i_usercuts


      COMMON/rcutdata/
     &  e_min_lep,pt_min_lep,
     &  eta_max_onelep,
     &  eta_max_lep,ptmiss_min,
     &  e_min_j,pt_min_j,eta_max_j,
     &  eta_def_jf_min,eta_def_jb_max,eta_def_jc_max,
     &  pt_min_jcjc,rm_min_jj,rm_min_ll,rm_min_jlep,
     &  rm_min_jcjc,rm_max_jcjc,rm_min_jfjb,
* six
     &  rm_min_4l,rm_min_2l2cq,
* YR
     &  rm_max_4l,rm_max_2l2cq,
* YRend
* sixend
* cuttop
     &   deltacuttop, 
* cuttopend
*ww
     &   rcutwlept,rcutptwelectron,
*wwend
*zw
     &   rcutzlept,
*zwend
     &  eta_min_jfjb,
     &  d_ar_jj,d_ar_jlep,d_ar_leplep,
     &  thetamin_jj,thetamin_jlep,
     &  thetamin_leplep


      COMMON/icutdataos/
     &   iextracuts,
     &   i_e_min_lepos,i_pt_min_lepos,
     &   i_eta_max_onelepos,
     &   i_eta_max_lepos,i_ptmiss_minos,
     &   i_e_min_jos,i_pt_min_jos,i_eta_max_jos,i_eta_jf_jb_jcos,
     &   i_pt_min_jcjcos,i_rm_min_jjos,i_rm_min_llos,i_rm_min_jlepos,
     &   i_rm_min_jcjcos,i_rm_max_jcjcos,i_rm_min_jfjbos,
* six
     &   i_rm_min_4los,i_rm_min_2l2cqos,
* sixend
* cuttop
     &   i_deltacuttopos, 
* cuttopend
     &   i_eta_min_jfjbos,
     &   i_d_ar_jjos,i_d_ar_jlepos,i_d_ar_leplepos,
     &   i_thetamin_jjos,i_thetamin_jlepos,
     &   i_thetamin_leplepos,
     &   i_usercutsos


      COMMON/rcutdataos/
     &  e_min_lepos,pt_min_lepos,
     &  eta_max_onelepos,
     &  eta_max_lepos,ptmiss_minos,
     &  e_min_jos,pt_min_jos,eta_max_jos,
     &  eta_def_jf_minos,eta_def_jb_maxos,eta_def_jc_maxos,
     &  pt_min_jcjcos,rm_min_jjos,rm_min_llos,rm_min_jlepos,
     &  rm_min_jcjcos,rm_max_jcjcos,rm_min_jfjbos,
* six
     &  rm_min_4los,rm_min_2l2cqos,
* sixend
* cuttop
     &   deltacuttopos, 
* cuttopend
     &  eta_min_jfjbos,
     &  d_ar_jjos,d_ar_jlepos,d_ar_leplepos,
     &  thetamin_jjos,thetamin_jlepos,
     &  thetamin_leplepos


